import numpy as np
import numpy as np
import pandas as pd
for i in range(100):
    print(100)


